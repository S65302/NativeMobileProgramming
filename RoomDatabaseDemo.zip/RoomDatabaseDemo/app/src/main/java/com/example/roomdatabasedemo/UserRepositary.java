package com.example.roomdatabasedemo;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

 class UserRepository {
    private final UserDao userDao;

    // Constructor using Application context
    public UserRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application); // Get the AppDatabase instance
        userDao = db.userDao(); // Access userDao() from AppDatabase
    }

    // Constructor using a provided UserDao (if needed for testing or other purposes)
    public UserRepository(UserDao userDao) {
        this.userDao = userDao;
    }

    // Insert a user into the database in a background thread
    public void insert(final User user) {
        new Thread(() -> userDao.insert(user)).start();
    }

    // Get all users
    public LiveData<List<User>> getAllUsers() {
        return userDao.getAllUsers(); // Return LiveData from DAO
    }

    // Update a user in the database in a background thread
    public void update(User user) {
        new Thread(() -> userDao.update(user)).start();
    }

    // Delete a user from the database in a background thread
    public void delete(User user) {
        new Thread(() -> userDao.delete(user)).start();
    }

    // Method to search users by name (correct method name)
    public LiveData<List<User>> searchUsersByName(String name) {
        return userDao.searchUsersByName(name); // This matches the UserDao method name
    }

    // Method to fetch users with their tasks
    public LiveData<List<UserWithTasks>> getUsersWithTasks() {
        return userDao.getUsersWithTasks(); // Return LiveData from DAO
    }
}

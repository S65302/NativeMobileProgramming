package com.example.roomdatabasedemo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class UserAdapter extends ListAdapter<User, UserAdapter.UserViewHolder> {

    private static OnUserClickListener onUserClickListener = null;

    public UserAdapter(OnUserClickListener listener) {
        super(new DiffCallback());
        this.onUserClickListener = listener;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_item, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        User user = getItem(position);
        holder.bind(user);
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        private final TextView nameText, ageText;
        private final Button updateButton, deleteButton;

        public UserViewHolder(View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.textName);
            ageText = itemView.findViewById(R.id.textAge);
            updateButton = itemView.findViewById(R.id.buttonUpdate);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }

        public void bind(final User user) {
            nameText.setText(user.getName());
            ageText.setText("Age: " + user.getAge());

            updateButton.setOnClickListener(v -> {
                if (onUserClickListener != null) {
                    onUserClickListener.onUpdateClick(user);
                }
            });

            deleteButton.setOnClickListener(v -> {
                if (onUserClickListener != null) {
                    onUserClickListener.onDeleteClick(user);
                }
            });
        }
    }

    public static class DiffCallback extends DiffUtil.ItemCallback<User> {
        @Override
        public boolean areItemsTheSame(User oldItem, User newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(User oldItem, User newItem) {
            return oldItem.equals(newItem);
        }
    }

    // Listener interface for click actions
    public interface OnUserClickListener {
        void onUpdateClick(User user);
        void onDeleteClick(User user);
    }
}


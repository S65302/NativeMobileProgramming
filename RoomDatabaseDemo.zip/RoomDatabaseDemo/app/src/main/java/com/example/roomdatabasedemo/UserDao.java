package com.example.roomdatabasedemo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void insert(User user);

    @Query("SELECT * FROM user_table ORDER BY id ASC")
    LiveData<List<User>> getAllUsers();

    @Update
    void update(User user);

    @Delete
    void delete(User user);

    // Method to search users by name
    @Query("SELECT * FROM user_table WHERE name LIKE :name")
    LiveData<List<User>> searchUsersByName(String name);

    // Method to fetch users with their tasks
    @Query("SELECT * FROM user_table")
    LiveData<List<UserWithTasks>> getUsersWithTasks();
}


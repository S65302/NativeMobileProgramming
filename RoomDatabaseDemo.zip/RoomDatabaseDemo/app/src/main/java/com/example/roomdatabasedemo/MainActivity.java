package com.example.roomdatabasedemo;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private UserViewModel userViewModel;
    private EditText nameInput, ageInput, searchBar;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize ViewModel
        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);

        // Find Views
        nameInput = findViewById(R.id.editTextName);
        ageInput = findViewById(R.id.editTextAge);
        searchBar = findViewById(R.id.searchBar);
        addButton = findViewById(R.id.buttonAdd);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // Setup RecyclerView
        UserAdapter adapter = new UserAdapter(new UserAdapter.OnUserClickListener() {
            @Override
            public void onUpdateClick(User user) {
                // Pre-fill EditText fields with user details for editing
                nameInput.setText(user.getName());
                ageInput.setText(String.valueOf(user.getAge()));

                // Change the action of the Add button to "Update"
                addButton.setText("Update");

                // Set up the button to update the user on clicking
                addButton.setOnClickListener(v -> {
                    user.setName(nameInput.getText().toString());
                    user.setAge(Integer.parseInt(ageInput.getText().toString()));
                    userViewModel.update(user);  // Update user in the database

                    addButton.setText("Add User");  // Reset button text
                    clearInputs();  // Clear input fields after update
                });
            }

            @Override
            public void onDeleteClick(User user) {
                // Delete user from the database
                userViewModel.delete(user);
                clearInputs();  // Clear input fields after delete
            }
        });
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Add Button Click Listener for adding new users
        addButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString();
            int age = Integer.parseInt(ageInput.getText().toString());
            User user = new User(name, age);

            // Insert user into the database
            userViewModel.insert(user);
            clearInputs();  // Clear input fields after adding
        });

        // Observe changes in the user list
        userViewModel.getAllUsers().observe(this, new Observer<List<User>>() {
            @Override
            public void onChanged(List<User> users) {
                // Update RecyclerView with new list of users
                adapter.submitList(users);
            }
        });

        // Add TextWatcher to search bar
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action needed
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Trigger search when text changes
                String query = s.toString();
                // Call the correct method searchUsersByName
                userViewModel.searchUsersByName(query).observe(MainActivity.this, new Observer<List<User>>() {
                    @Override
                    public void onChanged(List<User> users) {
                        // Update RecyclerView with filtered user list
                        adapter.submitList(users);
                    }
                });
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No action needed
            }
        });
    }

    // Helper method to clear input fields
    private void clearInputs() {
        nameInput.setText("");
        ageInput.setText("");
    }
}

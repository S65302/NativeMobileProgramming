package com.example.roomdatabasedemo;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UserViewModel extends AndroidViewModel {
    private final UserRepository userRepository;
    private final LiveData<List<User>> allUsers;

    public UserViewModel(Application application) {
        super(application);
        userRepository = new UserRepository(application);
        allUsers = userRepository.getAllUsers(); // Get all users
    }

    // Method to search users by name
    public LiveData<List<User>> searchUsersByName(String name) {
        return userRepository.searchUsersByName(name); // Correct method call here
    }

    // Get all users
    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    // Insert, Update, Delete methods for users
    public void insert(User user) {
        userRepository.insert(user);
    }

    public void update(User user) {
        userRepository.update(user);
    }

    public void delete(User user) {
        userRepository.delete(user);
    }
}

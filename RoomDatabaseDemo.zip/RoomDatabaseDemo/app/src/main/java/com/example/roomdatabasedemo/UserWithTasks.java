package com.example.roomdatabasedemo;

import androidx.room.Embedded;
import androidx.room.Relation;
import java.util.List;

public class UserWithTasks {

    @Embedded
    private User user; // This will hold the User data

    @Relation(parentColumn = "id", entityColumn = "userId")
    private List<Task> tasks; // This will hold the list of related Task entities

    // Getter for user
    public User getUser() {
        return user;
    }

    // Setter for user
    public void setUser(User user) {
        this.user = user;
    }

    // Getter for tasks
    public List<Task> getTasks() {
        return tasks;
    }

    // Setter for tasks
    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }
}

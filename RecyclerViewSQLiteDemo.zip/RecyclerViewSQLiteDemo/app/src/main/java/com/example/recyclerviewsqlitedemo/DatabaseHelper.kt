package com.example.recyclerviewsqlitedemo

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "userDatabase.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "users"
        private const val COL_ID = "id"
        private const val COL_NAME = "name"
        private const val COL_AGE = "age"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Create users table
        val CREATE_TABLE = "CREATE TABLE $TABLE_USERS ($COL_ID INTEGER PRIMARY KEY, $COL_NAME TEXT, $COL_AGE INTEGER)"
        db?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    // Method to get all users from the database
    fun getAllUser(): List<User> {
        val userList = mutableListOf<User>()
        val db = readableDatabase // Get a readable database

        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_USERS", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndex(COL_ID))
                val name = cursor.getString(cursor.getColumnIndex(COL_NAME))
                val age = cursor.getInt(cursor.getColumnIndex(COL_AGE))

                val user = User(id, name, age)
                userList.add(user)
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()

        return userList
    }

    // Add User to the database
    fun addUser(name: String, age: Int) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_NAME, name)
        values.put(COL_AGE, age)

        db.insert(TABLE_USERS, null, values)
        db.close()
    }
}


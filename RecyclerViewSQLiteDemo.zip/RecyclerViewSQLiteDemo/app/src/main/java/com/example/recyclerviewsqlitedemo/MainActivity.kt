package com.example.recyclerviewsqlitedemo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var userAdapter: UserAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var addUserButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recycler_view)
        addUserButton = findViewById(R.id.btn_add_user)

        addUserButton.setOnClickListener {
            showAddUserDialog()
        }

        setupRecycleView()
        loadUserData()
    }

    private fun setupRecycleView() {
        userAdapter = UserAdapter(emptyList()) // Initialize adapter with an empty list
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = userAdapter // Set adapter to the RecyclerView
    }

    private fun loadUserData() {
        val users = databaseHelper.getAllUser()
        userAdapter.updateData(users) // Update the adapter with the new data
        if (users.isEmpty()) {
            println("No users found in the database.")
        }
    }

    private fun showAddUserDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add User")

        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.dialog_add_user, null)
        builder.setView(dialogLayout)

        val etName = dialogLayout.findViewById<EditText>(R.id.et_name)
        val etAge = dialogLayout.findViewById<EditText>(R.id.et_age)

        builder.setPositiveButton("Add") { dialog, _ ->
            val name = etName.text.toString()
            val age = etAge.text.toString().toIntOrNull()

            if (name.isNotEmpty() && age != null) {
                // Add user to the database
                databaseHelper.addUser(name, age)

                // Reload the data and update the RecyclerView
                loadUserData()

                // Show a toast to confirm the user is added
                Toast.makeText(this, "User added", Toast.LENGTH_SHORT).show()
            } else {
                // Show an error message if input is invalid
                Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }
}

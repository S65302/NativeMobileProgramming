package com.example.fragmentexample;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

    private TextView textView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);
        textView = view.findViewById(R.id.textView);  // Find the TextView to update
        return view;
    }

    // Method to update the TextView with data
    public void updateData(String data) {
        if (textView != null) {
            textView.setText(data);  // Set the received data in the TextView
            Log.d("SecondFragment", "Data updated: " + data);
        }
    }
}

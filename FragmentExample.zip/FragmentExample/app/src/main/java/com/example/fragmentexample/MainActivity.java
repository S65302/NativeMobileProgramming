package com.example.fragmentexample;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Dynamically load SecondFragment into the container if it's not already loaded
        if (savedInstanceState == null) {
            SecondFragment secondFragment = new SecondFragment();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.secondFragment, secondFragment);  // Replace the container with SecondFragment
            transaction.commit();
        }

        // Send data to SecondFragment
        Log.d("MainActivity", "Sending data to SecondFragment...");
        sendDataToSecondFragment("Hello from MainActivity!");
    }

    // Method to send data to SecondFragment
    public void sendDataToSecondFragment(String data) {
        SecondFragment secondFragment = (SecondFragment) getSupportFragmentManager().findFragmentById(R.id.secondFragment);
        if (secondFragment != null) {
            secondFragment.updateData(data);  // Update the TextView in SecondFragment
            Log.d("MainActivity", "Data sent: " + data);
        }
    }
}

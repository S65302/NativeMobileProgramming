package com.example.sqlitedemo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "UserDatabase"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "Users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_AGE = "age"
    }

    override fun onCreate(database: SQLiteDatabase?) {
        val createTable = ("CREATE TABLE $TABLE_USERS ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "$COLUMN_NAME TEXT, "
                + "$COLUMN_AGE INTEGER)")
        database?.execSQL(createTable)
    }

    override fun onUpgrade(database: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        database?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(database)
    }

    // Method to add a user
    fun addUser(name: String, age: Int): Boolean {
        val database = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_NAME, name)
            put(COLUMN_AGE, age)
        }
        val result = database.insert(TABLE_USERS, null, contentValues)
        database.close()
        return result != -1L
    }

    // Method to update user information based on ID
    fun updateUser(id: Int, newName: String, newAge: Int): Boolean {
        val database = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_NAME, newName)
            put(COLUMN_AGE, newAge)
        }
        val result = database.update(TABLE_USERS, contentValues, "$COLUMN_ID=?", arrayOf(id.toString()))
        database.close()
        return result > 0
    }

    // Method to delete a user based on ID or name
    fun deleteUser(id: Int? = null, name: String? = null): Boolean {
        val database = this.writableDatabase

        val result = when {
            id != null -> database.delete(TABLE_USERS, "$COLUMN_ID=?", arrayOf(id.toString()))
            !name.isNullOrEmpty() -> database.delete(TABLE_USERS, "$COLUMN_NAME=?", arrayOf(name))
            else -> return false // No ID or name provided
        }

        database.close()
        return result > 0
    }

    // Method to retrieve all users, sorted alphabetically by name or by age
    fun getAllUsers(sortByAge: Boolean = false): List<String> {
        val userList = ArrayList<String>()
        val database = this.readableDatabase
        val orderBy = if (sortByAge) "$COLUMN_AGE ASC" else "$COLUMN_NAME ASC"
        val cursor = database.rawQuery("SELECT * FROM $TABLE_USERS ORDER BY $orderBy", null)

        if (cursor.moveToFirst()) {
            do {
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
                val age = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AGE))
                userList.add("Name: $name, Age: $age")
            } while (cursor.moveToNext())
        }
        cursor.close()
        database.close()
        return userList
    }
}

package com.example.sqlitedemo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var nameEditText: EditText
    private lateinit var ageEditText: EditText
    private lateinit var userIdEditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var addButton: Button
    private lateinit var updateButton: Button
    private lateinit var deleteButton: Button
    private lateinit var viewButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the UI components
        nameEditText = findViewById(R.id.et_name)
        ageEditText = findViewById(R.id.et_age)
        userIdEditText = findViewById(R.id.et_user_id)
        resultTextView = findViewById(R.id.tv_result)
        addButton = findViewById(R.id.btn_add)
        updateButton = findViewById(R.id.btn_update)
        deleteButton = findViewById(R.id.btn_delete)
        viewButton = findViewById(R.id.btn_view)

        // Initialize the DatabaseHelper
        databaseHelper = DatabaseHelper(this)

        // Set button click listeners
        addButton.setOnClickListener { addUser() }
        updateButton.setOnClickListener { updateUser() }
        deleteButton.setOnClickListener { deleteUser() }
        viewButton.setOnClickListener { viewUsers() }
    }

    private fun addUser() {
        val name = nameEditText.text.toString()
        val age = ageEditText.text.toString().toIntOrNull()

        if (name.isNotEmpty() && age != null) {
            val success = databaseHelper.addUser(name, age)
            if (success) {
                Toast.makeText(this, "User added successfully!", Toast.LENGTH_SHORT).show()
                nameEditText.text.clear()
                ageEditText.text.clear()
            } else {
                Toast.makeText(this, "Failed to add user", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please enter a valid name and age", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateUser() {
        val id = userIdEditText.text.toString().toIntOrNull()
        val name = nameEditText.text.toString()
        val age = ageEditText.text.toString().toIntOrNull()

        if (id != null && name.isNotEmpty() && age != null) {
            val success = databaseHelper.updateUser(id, name, age)
            if (success) {
                Toast.makeText(this, "User updated successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Failed to update user", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please enter valid ID, name, and age", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteUser() {
        val idText = findViewById<EditText>(R.id.et_user_id).text.toString()
        val nameText = findViewById<EditText>(R.id.et_name).text.toString()
        val id = idText.toIntOrNull()

        // Call deleteUser without named parameters
        val success = if (id != null) {
            databaseHelper.deleteUser(id)
        } else if (nameText.isNotEmpty()) {
            databaseHelper.deleteUser(name = nameText)
        } else {
            Toast.makeText(this, "Please enter a user ID or name", Toast.LENGTH_SHORT).show()
            return
        }

        if (success) {
            Toast.makeText(this, "User deleted successfully", Toast.LENGTH_SHORT).show()
            findViewById<EditText>(R.id.et_user_id).text.clear()
            findViewById<EditText>(R.id.et_name).text.clear()
        } else {
            Toast.makeText(this, "Failed to delete user", Toast.LENGTH_SHORT).show()
        }
    }

    private fun viewUsers() {
        val users = databaseHelper.getAllUsers()
        resultTextView.text = if (users.isNotEmpty()) {
            users.joinToString("\n")
        } else {
            "No users found"
        }
    }
}
